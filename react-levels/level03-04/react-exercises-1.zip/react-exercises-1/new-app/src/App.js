import "./App.css";
import ConditionalRendering from "./exercises/1_ConditionalRendering";
import ListOfProducts from "./exercises/2_ListOfProducts";


function App() {
  return (
    <div className="App">
      {/* <ConditionalRendering /> */}
      {/* <ListOfProducts/> */}
      
    </div>
  );
}

export default App;
